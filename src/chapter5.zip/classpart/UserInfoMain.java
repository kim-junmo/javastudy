package chapter5.classpart;

public class UserInfoMain {

	public static void main(String[] args) {
		
		//객체 생성
		UserInfo user1 = new UserInfo();
		
		// 회원가입 페이지로 사용자 데이터를 입력받아 UserInfo 클래스의 객체에 적용이 된다.
		// 스프링을 통해, 객체가 가지고 있는 데이터를 데이터베이스에 저장하게 된다.
		

	}

}
