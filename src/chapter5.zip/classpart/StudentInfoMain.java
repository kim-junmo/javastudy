package chapter5.classpart;

public class StudentInfoMain {

	public static void main(String[] args) {
		
		// Student클래스 사용. 클래스는 데이터 타입 / 데이터 타입 이름;
		Student stu1 = new Student();
		Student stu2 = new Student();

	}

}
