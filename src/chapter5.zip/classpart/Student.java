package chapter5.classpart;

/*
 클래스?
  - 클래스는 데이터타입이다. 즉 기억장소를 생성하기 위한 데이터타입을 모아둔 집합체이다.
  - 설계도이다.
  - 재사용성.
 */
public class Student {
	//필드
	int studentID;
	String studentName;
	int grade;
	String address;	
	

}
