package chapter5.classpart;

// 회원기능에 필요한 회원정보를 저장하기 위한 클래스 설계(디자인)
public class UserInfo {

	String name;
	String userid;
	String passwd;
	String birth;
	String email;
	String tel;
	String zipcode;
	String addr;
	String addr2;
	

}
